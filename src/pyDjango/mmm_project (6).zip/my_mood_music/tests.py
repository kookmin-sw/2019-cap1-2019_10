from django.test import TestCase
import operator


# Create your tests here.
import json

jsonString ='{"faceId": "c8a2f7ff-316b-4440-a051-f1bdebe7bebf", "faceRectangle": {"top": 0, "left": 35, "width": 245, "height": 199}, "faceAttributes": {"age": 25.0, "emotion": {"anger": 0.0, "contempt": 0.099, "disgust": 0.073, "fear": 0.0, "happiness": 0.0, "neutral": 0.012, "sadness": 0.816, "surprise": 0.0}}}'

dict = json.loads(jsonString)

print(dict['faceAttributes']['emotion'])

emotions = dict['faceAttributes']['emotion']
sorted_x = sorted(emotions.items(), key=operator.itemgetter(1)) # dictionary를 value값으로 sorting

print(sorted_x[-1])



# anger = emotions['anger']
# contempt = emotions['contempt']
# disgust = emotions['disgust']
# fear = emotions['fear']
# happiness = emotions['happiness']
# neutral = emotions['neutral']
# sadness = emotions['sadness']
# surprise = emotions['surprise']
#
# print(contempt)


#
# def solution(base_year, base_month, base_day, interval):
#     answer = ''
#
#     total_days = 0
#     month_days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
#
#     for i in range(1, base_year):
#         total_days = total_days + 365
#         if (i % 4 == 0 and i % 100 != 0) or i % 400 == 0:
#             total_days = total_days + 1
#
#     if base_year % 400 == 0 and base_month >= 3:
#         total_days += 1
#     elif base_year % 100 == 0:
#         pass
#     elif base_year % 4 == 0 and base_month >= 3:
#         total_days += 1
#     else:
#         pass
#
#     for i in range(1, base_month):
#         total_days = total_days + month_days[i]
#
#     total_days = total_days + base_day + interval -1
#
#     if total_days % 7 == 0:
#         answer = "월"
#
#     if total_days % 7 == 1:
#         answer = "화"
#
#     if total_days % 7 == 2:
#         answer = "수"
#
#     if total_days % 7 == 3:
#         answer = "목"
#
#     if total_days % 7 == 4:
#         answer = "금"
#
#     if total_days % 7 == 5:
#         answer = "토"
#
#     if total_days % 7 == 6:
#         answer = "일"
#
#     return answer
#
#
# result = solution(2015, 1, 1, 1583)
# print(result)
