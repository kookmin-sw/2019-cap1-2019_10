from django.apps import AppConfig


class MyMoodMusicConfig(AppConfig):
    name = 'my_mood_music'
